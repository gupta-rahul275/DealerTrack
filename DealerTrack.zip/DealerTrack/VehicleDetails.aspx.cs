﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class VehicleDetails : System.Web.UI.Page
{
    IVehicleService _IVehicleService;

    public VehicleDetails() 
    {
        _IVehicleService = new VehicleService();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string csvPath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
        FileUpload1.SaveAs(csvPath);

        string csvData = File.ReadAllText(csvPath);

        List<Vehicle> lstVehicle = new List<Vehicle>();        
        
        //Execute a loop over the rows.  
        foreach (string row in csvData.Split('\n'))
        {
            Vehicle vehicle = new Vehicle();
            if (!string.IsNullOrEmpty(row))
            {
                string[] cells = row.Split(',');
                vehicle.dealerNumber = Convert.ToInt32(cells[0]);
                vehicle.customerName = cells[1];   
                vehicle.dealershipName = cells[2];
                vehicle.vehicle = cells[3];
                vehicle.price = cells[4];
                vehicle.date = Convert.ToDateTime(cells[5]);
            }
            lstVehicle.Add(vehicle);
        }  
    }
}