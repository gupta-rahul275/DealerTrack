﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public interface IVehicleService
{
    public IVehicleService() { }

    public List<Vehicle> Result();

    public bool Upload(string file);
}
