﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IVehicleService
/// </summary>
public class VehicleService : IVehicleService
{
   

    public bool Upload(string file)
    {
     
    }


    public List<Vehicle> Result()
    {
        //var uploadData = Session["vehicle"];
        List<Vehicle> lstVehicle = new List<Vehicle>();
        Vehicle vehicle = new Vehicle();
        vehicle.customerName = "";
        vehicle.date = new DateTime();
        vehicle.dealerNumber = 0;
        vehicle.dealershipName = "";
        vehicle.price ="";
        lstVehicle.Add(vehicle);
        return lstVehicle;
    }
}