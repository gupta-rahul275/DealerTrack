﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Vehicle
/// </summary>
public class Vehicle
{
	public Vehicle()
	{
        dealerNumber = null;
        customerName = string.Empty;
        dealershipName = string.Empty;
        vehicle = string.Empty;
        price = string.Empty;
        date = null;
	}

    private int? _dealerNumber { get; set; }
    public int? dealerNumber { get { return _dealerNumber; } set { _dealerNumber = value; } }

    private string _customerName { get; set; }
    public string customerName { get { return _customerName; } set { _customerName = value; } }

    private string _dealershipName { get; set; }
    public string dealershipName { get { return _dealershipName; } set { _dealershipName = value; } }

    private string _vehicle { get; set; }
    public string vehicle { get { return _vehicle; } set { _vehicle = value; } }

    private string _price { get; set; }
    public string price { get { return _price; } set { _price = value; } }

    private DateTime? _date { get; set; }
    public DateTime? date { get { return _date; } set { _date = value; } }
}